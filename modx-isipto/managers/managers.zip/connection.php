<?php
$host = 'localhost'; // адрес сервера 
$database = 'managers'; // имя базы данных
$user = 'root'; // имя пользователя
$password = ''; // пароль
?>