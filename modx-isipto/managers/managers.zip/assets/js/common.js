$(document).ready(function () {


    svg4everybody({});
    /*Резиновая по высоте карта с блоком контактов внутри него. Опирается на высоту .contacts.*/
    if (window.matchMedia('(min-width: 992px)').matches) {
        var mapHeight = $('.contacts').innerHeight();
        $('.map').innerHeight(mapHeight + 110);
    }
     /* Автоматическое проставление id и for для label и input. */
    var bindLabels, guid;
    guid = function() {
        var s4;
        s4 = function() {
            return Math.floor((1 + Math.random()) * 0x10000).toString(16).substring(1);
        };
        return s4() + s4() + '-' + s4() + '-' + s4() + '-' + s4() + '-' + s4() + s4() + s4();
    };
    window.guid = guid;
    bindLabels = function() {
        $('input[type="checkbox"], input[type="radio"]').not('[id]').each(function() {
            var id = guid();
                th = $(this);
            th.attr('id', id);
            if (th.next().is('label')) {
                return th.next().attr('for', id);
            }
        });
        return $('label').not('[for]').each(function() {
            var id = guid();
                th = $(this);
            if (th.next().is('input,textarea,select')) {
                th.attr('for', id);
                return th.next().attr('id', id);
            } else if (th.prev().is('input,textarea,select')) {
                th.attr('for', id);
                return th.prev().attr('id', id);
            }
        });
    };
    bindLabels();
});